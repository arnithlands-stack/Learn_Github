/**
 * Form No.17 — Activity Implementation Plan
 * NNT National Park Management Office
 * app.js
 */

'use strict';

// ═══════════════════════════════════════════
// DEFAULT SEED DATA
// ═══════════════════════════════════════════
const SEED = {
  b21: [
    { desc: 'ຫົວໜ້າທີມ / Team Leader',          org: 'ກອຊ.ນທ',    pax: 1, days: 3, nights: 2, dsa: 150000, acc: 100000 },
    { desc: 'ພະນັກງານວິຊາການ / Technical Staff', org: 'ກອຊ.ນທ',    pax: 2, days: 3, nights: 2, dsa: 120000, acc:  80000 },
    { desc: 'ຊ່ຽວຊານ / Consultant',               org: 'ຊ່ຽວຊານ',  pax: 1, days: 3, nights: 2, dsa: 200000, acc: 150000 },
  ],
  b22: [
    { desc: 'ພະນັກງານ ເມືອງ / District Officer', org: 'ຫ້ອງການ ພລ', pax: 4, days: 3, nights: 2, dsa: 100000, acc: 70000 },
    { desc: 'ຕາງໜ້າ ບ້ານ / Village Rep.',         org: 'ບ້ານ',       pax: 8, days: 3, nights: 2, dsa:  80000, acc: 60000 },
  ],
  b23: [
    { desc: 'ນ້ຳມັນລົດ 4WD',    litres: 120, qty: 1, price: 9500 },
    { desc: 'ນ້ຳມັນລົດຈັກ',     litres:  20, qty: 3, price: 9500 },
  ],
  b24: [
    { desc: 'ຄ່າເຊົ່າຫ້ອງ / Hall rental',  unit: 'ຄັ້ງ',    pax:  1, days: 3, rate: 500000 },
    { desc: 'ວັດສະດຸ / Stationery',          unit: 'ຊຸດ',     pax: 30, days: 1, rate:  10000 },
    { desc: 'ກາເຟ-ນ້ຳດື່ມ / Refreshment',   unit: 'ຄົນ/ມື້', pax: 30, days: 3, rate:  15000 },
    { desc: 'ອາຫານທ່ຽງ / Lunch',             unit: 'ຄົນ/ມື້', pax: 30, days: 3, rate:  30000 },
  ],
  b25: [
    { desc: 'ລົດ 4WD',             qty: 1, trips: 2, days: 3, rate: 400000 },
    { desc: 'ລົດຈັກ / Motorbike',  qty: 3, trips: 1, days: 3, rate:  80000 },
  ],
  b26: [
    { desc: 'ກະດາດ A4',          unit: 'ແຣ້ມ', qty: 5, price: 35000 },
    { desc: 'ຊຸດເຄື່ອງຂຽນ',      unit: 'ຊຸດ',  qty: 3, price: 25000 },
  ],
};

// Map tbody id → row type
const TABLE_MAP = {
  b21: 'dsa',
  b22: 'dsa',
  b23: 'fuel',
  b24: 'admin',
  b25: 'transport',
  b26: 'equip',
};

// ═══════════════════════════════════════════
// TAB SWITCHING
// ═══════════════════════════════════════════
function switchTab(id, el) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  el.classList.add('active');
  if (id === 't3') refreshSummary();
}

// ═══════════════════════════════════════════
// PARTICIPANTS
// ═══════════════════════════════════════════
function addPax() {
  const tb = document.getElementById('paxBody');
  const n  = tb.rows.length + 1;
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td class="del"><button class="del-btn" onclick="delRow(this)">✕</button></td>
    <td class="no" data-n>${n}</td>
    <td><input type="text" placeholder="ຊື່ ນາມສະກຸນ..." style="min-width:140px;width:100%"></td>
    <td><input type="text" placeholder="ຕຳແໜ່ງ..."       style="min-width:110px;width:100%"></td>
    <td><input type="text" placeholder="ພາກສ່ວນ..."       style="min-width:120px;width:100%"></td>
    <td><input type="text" placeholder="020..."           style="min-width:100px;width:100%"></td>
  `;
  tb.appendChild(tr);
}

// ═══════════════════════════════════════════
// DELETE ROW (works for all tables)
// ═══════════════════════════════════════════
function delRow(btn) {
  const tr = btn.closest('tr');
  const tb = tr.parentElement;
  tr.remove();
  // Re-number rows
  tb.querySelectorAll('[data-n]').forEach((cell, i) => {
    cell.textContent = i + 1;
  });
  calcAll();
}

// ═══════════════════════════════════════════
// ADD BUDGET ROW
// ═══════════════════════════════════════════
function addRow(tbId, type, d = {}) {
  const tb = document.getElementById(tbId);
  const n  = tb.rows.length + 1;
  const tr = document.createElement('tr');

  // Helper: get numeric value or default 0
  const v  = (f, def = 0) => (d[f] !== undefined ? d[f] : def);
  // Helper: get string value or empty
  const vs = (f) => d[f] || '';

  if (type === 'dsa') {
    tr.innerHTML = `
      <td class="del"><button class="del-btn" onclick="delRow(this)">✕</button></td>
      <td class="no" data-n>${n}</td>
      <td><input type="text"   value="${vs('desc')}" placeholder="ລາຍການ..."  style="min-width:130px;width:100%"></td>
      <td><input type="text"   value="${vs('org')}"  placeholder="ພາກສ່ວນ..." style="min-width:80px;width:100%"></td>
      <td><input type="number" min="0" value="${v('pax')}"    oninput="calcDSA(this)"       data-f="pax"></td>
      <td><input type="number" min="0" value="${v('days')}"   oninput="calcDSA(this)"       data-f="days"></td>
      <td><input type="number" min="0" value="${v('nights')}" oninput="calcDSA(this)"       data-f="nights"></td>
      <td><input type="number" min="0" value="${v('dsa')}"    oninput="calcDSA(this)"       data-f="dsa"></td>
      <td><input type="number" min="0" value="${v('acc')}"    oninput="calcDSA(this)"       data-f="acc"></td>
      <td class="amt" data-t>0</td>
    `;
  } else if (type === 'fuel') {
    tr.innerHTML = `
      <td class="del"><button class="del-btn" onclick="delRow(this)">✕</button></td>
      <td class="no" data-n>${n}</td>
      <td><input type="text"   value="${vs('desc')}"   placeholder="ລາຍການ..." style="min-width:150px;width:100%"></td>
      <td><input type="number" min="0" value="${v('litres')}" oninput="calcFuel(this)"  data-f="litres"></td>
      <td><input type="number" min="0" value="${v('qty')}"    oninput="calcFuel(this)"  data-f="qty"></td>
      <td><input type="number" min="0" value="${v('price')}"  oninput="calcFuel(this)"  data-f="price"></td>
      <td class="amt" data-t>0</td>
    `;
  } else if (type === 'admin') {
    tr.innerHTML = `
      <td class="del"><button class="del-btn" onclick="delRow(this)">✕</button></td>
      <td class="no" data-n>${n}</td>
      <td><input type="text"   value="${vs('desc')}" placeholder="ລາຍການ..." style="min-width:150px;width:100%"></td>
      <td><input type="text"   value="${vs('unit')}" placeholder="ໜ່ວຍ..."   style="width:65px"></td>
      <td><input type="number" min="0" value="${v('pax')}"  oninput="calcAdmin(this)"  data-f="pax"></td>
      <td><input type="number" min="0" value="${v('days')}" oninput="calcAdmin(this)"  data-f="days"></td>
      <td><input type="number" min="0" value="${v('rate')}" oninput="calcAdmin(this)"  data-f="rate"></td>
      <td class="amt" data-t>0</td>
    `;
  } else if (type === 'transport') {
    tr.innerHTML = `
      <td class="del"><button class="del-btn" onclick="delRow(this)">✕</button></td>
      <td class="no" data-n>${n}</td>
      <td><input type="text"   value="${vs('desc')}"  placeholder="ລາຍການ..." style="min-width:150px;width:100%"></td>
      <td><input type="number" min="0" value="${v('qty')}"   oninput="calcTransport(this)" data-f="qty"></td>
      <td><input type="number" min="0" value="${v('trips')}" oninput="calcTransport(this)" data-f="trips"></td>
      <td><input type="number" min="0" value="${v('days')}"  oninput="calcTransport(this)" data-f="days"></td>
      <td><input type="number" min="0" value="${v('rate')}"  oninput="calcTransport(this)" data-f="rate"></td>
      <td class="amt" data-t>0</td>
    `;
  } else if (type === 'equip') {
    tr.innerHTML = `
      <td class="del"><button class="del-btn" onclick="delRow(this)">✕</button></td>
      <td class="no" data-n>${n}</td>
      <td><input type="text"   value="${vs('desc')}" placeholder="ລາຍການ..." style="min-width:150px;width:100%"></td>
      <td><input type="text"   value="${vs('unit')}" placeholder="ໜ່ວຍ..."   style="width:65px"></td>
      <td><input type="number" min="0" value="${v('qty')}"   oninput="calcEquip(this)" data-f="qty"></td>
      <td><input type="number" min="0" value="${v('price')}" oninput="calcEquip(this)" data-f="price"></td>
      <td class="amt" data-t>0</td>
    `;
  }

  tb.appendChild(tr);

  // Trigger calculation immediately for seeded rows
  const firstNum = tr.querySelector('input[type="number"]');
  if (firstNum) firstNum.dispatchEvent(new Event('input'));
}

// ═══════════════════════════════════════════
// CALCULATIONS
// ═══════════════════════════════════════════

/** Get numeric field value from a row */
function g(inp, field) {
  const row = inp.closest('tr');
  const el  = row.querySelector(`[data-f="${field}"]`);
  return el ? (parseFloat(el.value) || 0) : 0;
}

/** Write calculated amount to the row's [data-t] cell */
function setAmt(inp, val) {
  inp.closest('tr').querySelector('[data-t]').textContent = fmt(val);
}

function calcDSA(inp) {
  const total = ((g(inp,'days') * g(inp,'dsa')) + (g(inp,'nights') * g(inp,'acc'))) * g(inp,'pax');
  setAmt(inp, total);
  calcAll();
}

function calcFuel(inp) {
  setAmt(inp, g(inp,'litres') * g(inp,'qty') * g(inp,'price'));
  calcAll();
}

function calcAdmin(inp) {
  setAmt(inp, g(inp,'pax') * g(inp,'days') * g(inp,'rate'));
  calcAll();
}

function calcTransport(inp) {
  setAmt(inp, g(inp,'qty') * g(inp,'trips') * g(inp,'days') * g(inp,'rate'));
  calcAll();
}

function calcEquip(inp) {
  setAmt(inp, g(inp,'qty') * g(inp,'price'));
  calcAll();
}

/** Sum all [data-t] cells in a tbody */
function sumTb(id) {
  let total = 0;
  document.getElementById(id).querySelectorAll('[data-t]').forEach(cell => {
    total += parseFloat(cell.textContent.replace(/,/g, '')) || 0;
  });
  return total;
}

/** Update all section totals in the tfoot rows */
function calcAll() {
  ['b21','b22','b23','b24','b25','b26'].forEach((id, i) => {
    const sumEl = document.getElementById('s' + (21 + i));
    if (sumEl) sumEl.textContent = fmt(sumTb(id));
  });
}

/** Refresh the summary panel */
function refreshSummary() {
  calcAll();
  ['21','22','23','24','25','26'].forEach(n => {
    const el = document.getElementById('sum' + n);
    if (el) el.textContent = fmt(sumTb('b' + n)) + ' LAK';
  });
  const grand = ['b21','b22','b23','b24','b25','b26'].reduce((acc, id) => acc + sumTb(id), 0);
  document.getElementById('grandTotal').textContent = fmt(grand);
}

// ═══════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════

/** Format number with thousands separator */
function fmt(n) {
  return Math.round(n).toLocaleString('en-US');
}

/** Reset all form fields */
function resetForm() {
  if (!confirm('ລ້າງຂໍ້ມູນທັງໝົດ?')) return;
  document.querySelectorAll('input:not(#docDate):not(#docRef), textarea').forEach(el => {
    el.value = el.type === 'number' ? '0' : '';
  });
  document.querySelectorAll('[data-t]').forEach(c => c.textContent = '0');
  refreshSummary();
}

// ═══════════════════════════════════════════
// INITIALISE
// ═══════════════════════════════════════════
(function init() {
  // Set today's date
  document.getElementById('docDate').valueAsDate = new Date();

  // Seed participant rows
  for (let i = 0; i < 7; i++) addPax();

  // Seed budget tables
  Object.entries(SEED).forEach(([tbId, rows]) => {
    const type = TABLE_MAP[tbId];
    rows.forEach(d => addRow(tbId, type, d));
    addRow(tbId, type); // one blank trailing row
  });

  refreshSummary();
})();
