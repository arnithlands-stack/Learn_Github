# Form No.17 — ແຜນຈັດຕັ້ງປະຕິບັດກິດຈະກຳ
### Activity Implementation Plan
**NNT National Park Management Office — Nakai-Nam Theun**

---

## 📋 ກ່ຽວກັບ / About

Web app ສຳລັບກອກ ແລະ ຄຳນວນ **ແຜນຈັດຕັ້ງປະຕິບັດກິດຈະກຳ (Form No.17)** ຂອງ ກອງຄຸ້ມຄອງ ອຸທິຍານແຫ່ງຊາດ ນາກາຍ-ນໍ້າເທີນ.

A web-based form for completing and auto-calculating the **Activity Implementation Plan (Form No.17)** for the Nakai-Nam Theun National Park Management Office.

---

## 🚀 ໃຊ້ງານ / Usage

### ເປີດໃຊ້ / Open locally
```bash
# Clone the repository
git clone https://github.com/<your-username>/form17-nnt.git
cd form17-nnt

# Open in browser (no server needed)
open index.html
```

### GitHub Pages (ແນະນຳ / Recommended)
1. ໄປທີ່ **Settings → Pages**
2. ເລືອກ **Branch: main**, folder **/ (root)**
3. ກົດ **Save** — ລໍຖ້າ 1-2 ນາທີ
4. ເຂົ້າໃຊ້ທີ່: `https://<your-username>.github.io/form17-nnt/`

---

## 📁 ໂຄງສ້າງໄຟລ໌ / File Structure

```
form17-nnt/
├── index.html        ← ໜ້າຫຼັກ / Main page
├── css/
│   └── style.css     ← ຮູບແບບ / Styles
├── js/
│   └── app.js        ← ໂລຈິກ / Logic & calculations
└── README.md
```

---

## ✨ ຟີເຈີ / Features

| ໝວດ | ລາຍລະອຽດ |
|-----|-----------|
| **Tab I** | ລາຍລະອຽດກິດຈະກຳ (1.1–1.11): ຂໍ້ມູນທົ່ວໄປ, ຈຸດປະສົງ, ຕົວຊີ້ວັດ, ຜູ້ເຂົ້າຮ່ວມ, ໄລຍະເວລາ |
| **Tab II** | ງົບປະມານ 6 ໝວດ (2.1–2.6): DSA, ຄ່ານ້ຳມັນ, ຄ່າບໍລິຫານ, ຄ່າເດີນທາງ, ອຸປະກອນ |
| **Tab III** | ສະຫລຸບງົບ + ຍອດລວມທັງໝົດ |
| **Tab IV** | ລາຍເຊັນ ແລະ ການອານຸມັດ |
| **ຄຳນວນ** | Auto-calculate ທຸກແຖວ real-time |
| **ພິມ** | Print-ready layout |

---

## 🧮 ສູດຄຳນວນ / Formulas

| ໝວດ | ສູດ |
|-----|-----|
| 2.1 / 2.2 DSA | `((Days × DSA/Day) + (Nights × Acc/Night)) × Pax` |
| 2.3 ນ້ຳມັນ | `Litres × Qty × Price/Litre` |
| 2.4 ບໍລິຫານ | `Pax × Days × Rate/Day` |
| 2.5 ເດີນທາງ | `Qty × Trips × Days × Rate/Day` |
| 2.6 ອຸປະກອນ | `Qty × Price/Unit` |

---

## 🛠 ເຕັກໂນໂລຈີ / Tech Stack

- **HTML5** — semantic structure
- **CSS3** — custom properties, grid, flexbox
- **Vanilla JavaScript** — zero dependencies
- **Google Fonts** — Noto Sans Lao + DM Mono

---

## 📄 ລິຂະສິດ / License

© NNT National Park Management Office. Internal use only.
